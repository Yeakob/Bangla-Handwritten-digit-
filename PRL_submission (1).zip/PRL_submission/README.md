# Pattern Recognition Letters submission package
**Human Label Distributions and Ambiguity-Aware Benchmarking of Bangla Handwritten Digits**

## Files to upload
| Submission item | File |
|---|---|
| Manuscript (LaTeX source) | `latex/main.tex` + `references.bib`, `figures/`, `cas-dc.cls`, `cas-common.sty`, `elsarticle-num.bst`, `thumbnails/` |
| Highlights | `highlights.txt` (5 bullets, each under 85 characters) |
| Graphical abstract | `graphical_abstract.pdf` or `graphical_abstract.png` (2656 x 1062 px) |
| Supplementary material | `Supplementary_Material.pdf` (source: `latex/supplementary.tex`) |
| Declaration of interests | produce it with Elsevier's Declarations tool (.docx) |
| Authorship & Formatting Form | download from the submission site; upload as the cover letter |

`manuscript_preview.pdf`: 6 pages (the limit is 7 including references).

## Compile
Overleaf: upload `latex/` and compile `main.tex` with pdfLaTeX, then `supplementary.tex`.

## Still to fill in
1. Co-author names, affiliation, institutional emails and ORCID. The placeholders are `author@institution.edu` and `0000-0000-0000-0000`.
2. CRediT roles for co-authors.
3. Check the wording of the generative-AI declaration.
4. References: 20 entries carry DOIs. The remaining entries are proceedings (NeurIPS, ICML, MLSys, CVPR/ECCV where no DOI was added) or the NumtaDB arXiv preprint.
