# How Ambiguous Is Ekush? LaTeX source

## Compile
- Overleaf: upload this zip and set `main.tex` as the main document (compiler: pdfLaTeX).
- Locally: `latexmk -pdf main.tex` (or pdflatex, bibtex, pdflatex, pdflatex).
- `main.pdf` is a pre-compiled copy.

## Layout
- `main.tex`: the manuscript (two-column article, Times font, natbib `unsrtnat` numeric citations).
- `references.bib`: bibliography. **Check every entry against the original before submission.**
- `tables/t01–t22, tA1–tA2`: booktabs tables used in the paper, built from the notebook outputs.
- `tables/generated_by_notebook/`: the raw `.tex` tables exactly as the human-study notebook wrote them, for reference.
- `figures/sfig*, hfig01` (PDF): figures from the results zip, with the "[REAL DATA]" suptitle cropped off.
- `figures/mfig*` (PNG): Notebook 1 (model analysis) figures, extracted from the notebook outputs.
- `data/`: all result CSVs, `preregistration.json` and `DATASHEET.md`.

## Before submission
Search `main.tex` for red `\todo{...}` markers:
1. author names and affiliation
2. Stage-1 optimiser, learning rate, batch size, augmentation and initialisation (from `ekush_core.Config`)
3. annotator recruitment, background, compensation and consent/ethics
4. repository URL/DOI for the release
5. acknowledgements

To move to a journal template (IEEE, Elsevier, Springer), keep the body and swap the preamble. Tables already scale to the column or page width through `adjustbox`.
