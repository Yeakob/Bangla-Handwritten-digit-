# Ekush-Digits-Soft — human label distributions for ambiguous Bangla numerals

Status: **REAL DATA**
Instrument ID: b12741b6c6a57544 | Pre-registration SHA-256: e2b407b9789eaf92b6d7f4c58c9b6d462e978f143e5df64d796ac64c6e095c8d
Generated: 2026-09-27

## Composition
- Items: 1002 from the Ekush numeral test split (SHA-256 b67330bc40a2bb5e...)
- Strata (population / annotated): cl 2/2, high 600/600, mid 600/200, low 1822/200
- Annotators: 9 retained of 10 (excluded: A11)
- Judgements (retained, first presentation): 9,018
- Krippendorff's alpha: 0.9469 [0.9375, 0.9557] overall; cl 1.0000 [1.0000, 1.0000]; high 0.9204 [0.9058, 0.9349]; mid 0.9814 [0.9708, 0.9899]; low 0.9882 [0.9787, 0.9962]

## Item categories (primary rule)
category
unambiguous           975
ambiguous              20
suspected_mislabel      4
insufficient            3

## Files
- `ekush_digits_soft_labels.csv` — votes, vote shares, reliability-weighted posteriors, noise-test p-values, and categories under three rules.
- `annotator_noise_rates.csv` — per-annotator error rates on clear control items.
- `ekush_digits_annotator_level.csv` — every response, including repeats and excluded annotators (flagged).
- `digit_confusion_cost.csv` — 10x10 ground cost learned from human co-voting.
- `preregistration.json` — thresholds fixed before annotation.
- `annotation_tool.html`, `ANNOTATOR_PROTOCOL.md` — the instrument as distributed.
- Item selection, model predictions and checkpoint hashes: Notebook 1 study package (study ID in the header).

## Collection protocol
Items were ranked by an ensemble ambiguity score (rank average of predictive entropy,
aleatoric entropy, top-2 margin and variation ratio) computed from the Notebook 1
ensemble (xception, resnet50v2, mobilenetv2, efficientnetb0, custom_cnn; all seeds). The test split was partitioned into disjoint
strata: a census of the top 100 confident-learning label-issue candidates (cl),
a census of the next 600 most ambiguous images (high), 200 sampled from the
following 600 (mid), and 200 sampled from the remainder (low).
Annotators saw opaque identifiers, no stored label and no model output, in a per-annotator
random order. 50 easy items were repeated
as attention checks. Exclusion rules were pre-registered.

## Recommended use
Report distributional metrics (JSD, soft Brier, cross-entropy, confusion cost) with
confidence intervals, and evaluate high- and low-agreement items separately. Corpus-level
estimates must use the stratum weights; unweighted means describe the annotated sample only.

## Known limitations
- Images are 28x28 in the public redistribution used here; some ambiguity may be a
  resolution artifact.
- Item selection is model-driven; the human distributions are not, and the strata keep
  corpus estimates valid.
- With 9 annotators the finest vote share is 1/9; item-level distributions are coarse.
- Annotators were not the writers and may not share every regional letterform convention.

## Licence
CC BY 4.0, subject to the Ekush terms of use. Citation: [add on acceptance]
