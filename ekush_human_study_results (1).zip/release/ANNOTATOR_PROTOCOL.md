# Annotator protocol — Bangla digit ambiguity study

## What to do
1. Open `annotation_tool.html` in any modern browser (Chrome, Firefox, Edge).
   No internet connection is needed after downloading.
2. Enter the annotator ID assigned to you, exactly as given.
3. Work through the items. Roughly 3.2 hours.
   Take breaks — your progress is saved automatically in the browser.
4. When finished, click **Download CSV** and email the file to the researcher.

## Rules
- Do **not** discuss any item with another annotator. Independence is the
  entire point; correlated annotators produce a distribution that measures
  your group's conversation rather than the handwriting.
- Do **not** use the same browser profile as another annotator.
- Report confidence honestly. "Guess" is a valid and useful answer.
- Use **Illegible** when you genuinely cannot read the image, not when it is
  merely difficult. Use **Not a digit** if it is not a numeral at all.
- Do not go back to revise earlier answers systematically. Your first
  impression is the measurement.

## Keyboard
`0`-`9` select digit · `i` illegible · `n` not a digit ·
`c`/`p`/`g` confidence · `Enter` next · `Backspace` back

## Contact
Return the CSV to: [ADD YOUR EMAIL]
Study ID: b12741b6c6a57544. Items: 1002 unique, 50 repeated for quality control.
Tool build: b12741b6c6a57544 (shown at the top of the task screen).
