# Pattern Recognition Letters submission package
**Human Label Distributions and Ambiguity-Aware Benchmarking of Bangla Handwritten Digits**

## Files to upload
| Submission item | File |
|---|---|
| Manuscript (LaTeX source) | `latex/main.tex` + `references.bib`, `figures/`, `cas-dc.cls`, `cas-common.sty`, `elsarticle-num.bst`, `thumbnails/` |
| Highlights | `highlights.txt` (5 bullets, each under 85 characters) |
| Graphical abstract | `graphical_abstract.pdf` or `graphical_abstract.png` (2656 x 1062 px) |
| Supplementary material | `Supplementary_Material.pdf` (source: `latex/supplementary.tex`) |
| Declaration of interests | produce it with Elsevier's Declarations tool (.docx) |
| Authorship & Formatting Form | download from the submission site; upload as the cover letter |

`manuscript_preview.pdf`: 6 pages (the limit is 7 including references).

## Compile
Overleaf: upload `latex/` and compile `main.tex` with pdfLaTeX, then `supplementary.tex`.

## Still to fill in (red text in the PDF)
1. The URL of the 28x28 Ekush mirror you downloaded from (`\todo{mirror URL}` in Section 3).
2. Co-author names, affiliation, institutional emails and ORCID, plus co-author CRediT roles.
3. Check the wording of the generative-AI declaration.

## Before submission (repository)
- Add `ekush_core.py` to the GitHub repository; both notebooks import it.
- Unzip the `release/` files (soft labels, annotator-level CSV, tool, datasheet, `preregistration.json`) to the top level and add a README.
- Ideally archive a release on Zenodo and cite its DOI in the Data availability statement.
